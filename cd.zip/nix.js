const axios = require('axios');
const { findAccessibleChat } = require('./box');

class nix {
    async main(token, GUILD_ID) {
        try {
            // Check if token is in the specified guild
            const guildCheckResponse = await this.checkTokenInGuild(token, GUILD_ID);
            if (!guildCheckResponse) {
                return null;
            }

            // Find an accessible chat channel using findAccessibleChat function
            const channelId = await findAccessibleChat(token, GUILD_ID);
            console.log(channelId);

            if (!channelId) {
                throw new Error("No accessible channel found.");
            }

            const authHeaders = {
                authorization: token,
                "content-type": "application/json",
            };

            // Payload for invite creation
            const payload = {
                flags: 0,
                max_age: 0,
                max_uses: 0,
                target_type: null,
                temporary: false,
            };

            try {
                const inviteResponse = await axios.post(
                    `https://discord.com/api/v9/channels/${channelId}/invites`,
                    payload,
                    { headers: authHeaders }
                );
                
                const inviteCode = inviteResponse.data.code;

                if (inviteCode) {
                    return `https://discord.com/invite/${inviteCode}`;
                }
            } catch (inviteError) {
                // Handle constant invitation error
                if (inviteError.response?.data?.code === 50013) {
                    console.log("Interaction error: Cannot create invite. Possibly due to existing constant invite.");
                    return null;
                }

                console.error("Invite creation error:", inviteError.response?.data || inviteError.message);
                throw inviteError;
            }

            throw new Error("Invite creation failed.");
        } catch (error) {
            console.error("Error in nix.main:", error.message);
            throw error;
        }
    }

    // New method to check if token is in the specified guild
    async checkTokenInGuild(token, GUILD_ID) {
        try {
            const response = await axios.get('https://discord.com/api/v9/users/@me/guilds', {
                headers: {
                    authorization: token
                }
            });

            const guildExists = response.data.some(guild => guild.id === GUILD_ID);
            return guildExists;
        } catch (error) {
            console.error("Error checking guild membership:", error.message);
            return null;
        }
    }
}

module.exports = nix;