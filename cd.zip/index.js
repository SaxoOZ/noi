const { Client } = require('discord.js'); 
const Name = require('./fun');
const nix = require('./nix');
const {
    MessageActionRow,
    MessageButton,
    Modal,
    TextInputComponent,
    MessageSelectMenu,
    MessageEmbed,
  } = require('discord.js');;

  const fs = require('fs');
  const axios = require('axios');














  

const botInstance = new Name();
const inv = new nix();

//const token = "MTEwNDkzOTEyNjM4MzQ1MjE2MA.GX69De.oTKy02sJaL93aZ5IiM5BNmNmu40K03fHS66GTI";

const client = new Client({
    intents: [
        "GUILDS",
        "GUILD_MESSAGES",
        "GUILD_MEMBERS",
        "MESSAGE_CONTENT",
        "GUILD_BANS",
        "GUILD_VOICE_STATES",
    ],
});

client.on('ready', async () => {
    console.log(`Logged in as ${client.user.tag} v3!`);
    
});


client.on("messageCreate", async (message)=>{
    if (message.content !== "-search"){return}
    const row = new MessageActionRow()
    .addComponents(
    new MessageButton()
        .setCustomId("search")
        //.setLabel('Search')
        .setEmoji("🔍")
        .setStyle("SECONDARY"),
    )

    await message.channel.send({
        content: "find someone...",
        components: [row]
    });
})


client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    if (interaction.customId === 'search') {
        const modal = new Modal()
            .setCustomId('enterid')
            .setTitle('Enter Member id');

        const textInput = new TextInputComponent()
            .setCustomId('id')
            .setLabel('Enter Member id')
            .setPlaceholder('00000000000000000')
            .setStyle('SHORT');

        const modalRow = new MessageActionRow().addComponents(textInput);

        modal.addComponents(modalRow);

        await interaction.showModal(modal);
    }
});





const checker = async (tokens) => {
    const worked = [];

    for (const token of tokens) {
        try {
            const response = await axios.get("https://discord.com/api/v10/users/@me/connections", {
                headers: {
                    'Authorization': token
                }
            });

            if (response.status === 200) {
                worked.push(token);
            }
        } catch (error) {
            // Handle the error if needed
            console.error(`Error with token ${token}:`, error.response ? error.response.status : error.message);
        }
    }

    return worked;
};


client.on('interactionCreate', async (interaction) => {
    if (!interaction.isButton()) return;

    if (interaction.customId === 'invite') {
        await interaction.deferReply({ ephemeral: true });
        try {
            const guild_id = interaction.message.embeds[0].fields[1].value
                .split("channels/")[1]
                .split(")")[0];

            const data = fs.readFileSync('tokens.txt', 'utf-8');
            let tokens = data.split(/\r?\n/);

            // Use your checker function if needed
            tokens = await checker(tokens);

            let inviteUrl = null;

            for (const token of tokens) {
                try {
                    inviteUrl = await inv.main(token, guild_id);
                    

                    if (inviteUrl) break; // Stop if invite is created successfully
                } catch (error) {
                    console.error("Error with token:", token, error.message);
                }
            }

            
            if (!inviteUrl) {
                throw new Error("All tokens failed to create an invite.");
            }
            try{
            await interaction.user.send({ content: inviteUrl, ephemeral: true });
            await interaction.editReply({ content: `See ur DM <#1318650472352976967>`, ephemeral: true });
        }catch{
            interaction.editReply({ content: inviteUrl, ephemeral: true });
        }
        } catch (error) {
            console.error("Interaction error:", error.message);
            await interaction.editReply({ content: "Failed to create an invite.", ephemeral: true });
        }
    }
});
















client.on('interactionCreate', async interaction => {
    if (!interaction.isModalSubmit()) return;

    if (interaction.customId === 'enterid') {
        const userInput = interaction.fields.getTextInputValue('id');
        await interaction.deferReply({ ephemeral: true }); // Defer the interaction

        try {
            const data = fs.readFileSync('tokens.txt', 'utf-8');

            
            let tokens = data.split(/\r?\n/);

            tokens = await checker(tokens);



            var member;
var channel;

async function processTokensInBatches(tokens, batchSize) {
    for (let i = 0; i < tokens.length; i += batchSize) {
        // Select the current batch of tokens (4 at a time)
        const batch = tokens.slice(i, i + batchSize);

        try {
            // Process the batch in parallel
            const results = await Promise.any(batch.map(async (element) => {
                const cache = await botInstance.main(element, userInput);
                if (cache.m && cache.c) return cache;
                throw new Error("No match");
            }));

            // Stop if a result is found
            if (results) {
                member = results.m;
                channel = results.c;
                break; // Exit the loop if successful
            }
        } catch (error) {
            // Handle batch failure (optional, e.g., log or skip)
            console.error("Batch failed:", error);
        }
    }
}

const batchSize = 4; // Adjust to process 4 tokens at a time
await processTokensInBatches(tokens, batchSize);

if (member && channel) {
    
} else {

    await interaction.deleteReply();
    const embed = new MessageEmbed()
        .setColor("RED")
        .setTitle("❌ || User not found.")
    await interaction.followUp({embeds: [embed], ephemeral: true });
    
    return
}

            
/*var member
var channel
const result = await Promise.any(tokens.map(async (element) => {
    const cache = await botInstance.main(element, userInput);
    if (cache.m && cache.c) return cache;
    throw new Error("No match"); // Ensures Promise.any skips this result
}));

if (result) {
    member = result.m;
    channel = result.c;
}*/
        
            
            

           // console.log('Found channel:', channel.name);


            // Delete the deferred reply
            await interaction.deleteReply();

            const row = new MessageActionRow()
            .addComponents(
            new MessageButton()
                .setCustomId("invite")
                //.setLabel('Search')
                .setEmoji("📨")
                .setStyle("SECONDARY"),
            )
            
            const embed = new MessageEmbed()
                .setColor("GREEN") // Embed color
                //.setTitle('Channel Found')
                //.setDescription(`Found channel: ${channel.name}`)
                .setAuthor({
                    name: `${member.user.globalName}`, // Author name
                    iconURL: member.user.displayAvatarURL()
                })
                .setThumbnail(channel.guild.iconURL())
                .setFields(
                    { name: 'User', value: `<@${member.user.id}> - \`${member.user.username}\``, inline: false },
                    { name: 'Server', value: `[[ ${channel.guild.name} ]](https://discord.com/channels/${channel.guild.id})`, inline: false },
                    { name: 'Channel Name', value: `[[ ${channel.name} ]](https://discord.com/channels/${channel.guild.id}'${channel.id})`, inline: false },
                    { name: 'Channel', value: `<#${channel.id}>`, inline: false },
                   // { name: 'Category', value: channel.parent?.name || 'None', inline: true }
                )
                //.setFooter({ text: 'Search completed successfully' })
                .setTimestamp();
            // Send a follow-up message
            await interaction.followUp({embeds: [embed], components: [row], ephemeral: true });
        } catch (error) {
            console.error('Error:', error);

            // Edit the deferred reply with an error message
            await interaction.editReply({content:'An error occurred while processing your request.', ephemeral: true});
        }
    }
});



client.login("MTA3NTU2MDI0NTY4ODAxNjg5Ng.G2ZVjy.FudC_0vhFwnKhjVck6L0paXEC1iWCkO-0tsWoI");



process.on('unhandledRejection', (reason, p) => {
    console.log(' [Error_Handling] :: Unhandled Rejection/Catch');
    console.log(reason, p);
});
process.on('uncaughtException', (err, origin) => {
    console.log(' [Error_Handling] :: Uncaught Exception/Catch');
    console.log(err, origin);
});
process.on('uncaughtExceptionMonitor', (err, origin) => {
    console.log(' [Error_Handling] :: Uncaught Exception/Catch (MONITOR)');
    console.log(err, origin);
});