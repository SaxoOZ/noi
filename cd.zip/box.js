const axios = require('axios');

class DiscordChannelFinder {
    /**
     * Extract USER_ID from bot token
     * @param {string} token - Discord bot token
     * @returns {string|null} Extracted User ID
     */
    static extractUserIdFromToken(token) {
        try {
            // Split the token and take the first part
            const encodedId = token.split('.')[0];
            
            // Base64 decode the ID
            const decodedId = Buffer.from(encodedId, 'base64').toString('utf-8');
            
            return decodedId;
        } catch (error) {
            console.error('Error extracting User ID from token:', error);
            return null;
        }
    }

    /**
     * Decode Discord permission value into readable permissions
     * @param {bigint} permissionValue - Bitwise permission value
     * @returns {string[]} Array of permission names
     */
    static decodeDiscordPermissions(permissionValue) {
        const permissionMap = {
            // General Permissions
            [1n << 0n]:  "CREATE_INSTANT_INVITE",
            [1n << 1n]:  "KICK_MEMBERS",
            [1n << 2n]:  "BAN_MEMBERS",
            [1n << 3n]:  "ADMINISTRATOR",
            [1n << 4n]:  "MANAGE_CHANNELS",
            [1n << 5n]:  "MANAGE_GUILD",
            
            // Text Permissions
            [1n << 6n]:  "ADD_REACTIONS",
            [1n << 7n]:  "VIEW_AUDIT_LOG",
            [1n << 8n]:  "PRIORITY_SPEAKER",
            [1n << 9n]:  "STREAM",
            [1n << 10n]: "VIEW_CHANNEL",
            [1n << 11n]: "SEND_MESSAGES",
            [1n << 12n]: "SEND_TTS_MESSAGES",
            [1n << 13n]: "MANAGE_MESSAGES",
            [1n << 14n]: "EMBED_LINKS",
            [1n << 15n]: "ATTACH_FILES",
            [1n << 16n]: "READ_MESSAGE_HISTORY",
            [1n << 17n]: "MENTION_EVERYONE",
            [1n << 18n]: "USE_EXTERNAL_EMOJIS",
            
            // Voice Permissions
            [1n << 19n]: "VIEW_GUILD_INSIGHTS",
            [1n << 20n]: "CONNECT",
            [1n << 21n]: "SPEAK",
            [1n << 22n]: "MUTE_MEMBERS",
            [1n << 23n]: "DEAFEN_MEMBERS",
            [1n << 24n]: "MOVE_MEMBERS",
            [1n << 25n]: "USE_VAD",
            
            // Stage Voice Permissions
            [1n << 26n]: "REQUEST_TO_SPEAK",
            
            // Advanced Permissions
            [1n << 27n]: "MANAGE_ROLES",
            [1n << 28n]: "MANAGE_WEBHOOKS",
            [1n << 29n]: "MANAGE_EMOJIS_AND_STICKERS",
            [1n << 30n]: "USE_APPLICATION_COMMANDS",
            [1n << 31n]: "REQUEST_TO_SPEAK",
            
            // Additional Permissions
            [1n << 32n]: "MANAGE_THREADS",
            [1n << 33n]: "CREATE_PUBLIC_THREADS",
            [1n << 34n]: "CREATE_PRIVATE_THREADS",
            [1n << 35n]: "USE_EXTERNAL_STICKERS",
            [1n << 36n]: "SEND_MESSAGES_IN_THREADS",
            [1n << 37n]: "USE_EMBEDDED_ACTIVITIES",
            [1n << 38n]: "MODERATE_MEMBERS"
        };
        
        return Object.entries(permissionMap)
            .filter(([bit]) => permissionValue & BigInt(bit))
            .map(([_, permName]) => permName);
    }

    /**
     * Analyze permission overwrites for a Discord channel
     * @param {Array} permissionOverwrites - Permission overwrite array
     * @returns {Array} Detailed permission analysis
     */
    static analyzeChannelPermissions(permissionOverwrites) {
        return permissionOverwrites.map(overwrite => ({
            id: overwrite.id,
            type: overwrite.type === 0 ? 'Role' : 'User',
            allowed: this.decodeDiscordPermissions(BigInt(overwrite.allow)),
            denied: this.decodeDiscordPermissions(BigInt(overwrite.deny))
        }));
    }
}

/**
 * Find an accessible chat channel
 * @param {string} BOT_TOKEN - Discord bot token
 * @param {string} GUILD_ID - Discord guild ID
 * @returns {Promise<string|null>} Accessible channel ID or null
 */
async function findAccessibleChat(BOT_TOKEN, GUILD_ID) {
    const USER_ID = DiscordChannelFinder.extractUserIdFromToken(BOT_TOKEN);
    
    if (!USER_ID) {
        console.error('Failed to extract User ID from token');
        return null;
    }

    try {
        // Get user roles
        const memberResponse = await axios.get(
            `https://discord.com/api/v9/guilds/${GUILD_ID}/members/${USER_ID}`,
            { headers: { Authorization: BOT_TOKEN } }
        );
        const userRoles = memberResponse.data.roles;

        // Get guild roles to include @everyone role
        const rolesResponse = await axios.get(
            `https://discord.com/api/v9/guilds/${GUILD_ID}/roles`,
            { headers: { Authorization: BOT_TOKEN } }
        );
        const everyoneRole = rolesResponse.data.find(role => role.id === GUILD_ID);
        if (everyoneRole) {
            userRoles.push(everyoneRole.id);
        }

        // Get channels
        const channelsResponse = await axios.get(
            `https://discord.com/api/v9/guilds/${GUILD_ID}/channels`,
            { headers: { Authorization: BOT_TOKEN } }
        );
        
        // Filter text channels
        const textChannels = channelsResponse.data.filter(channel => channel.type === 0);

        // Find an accessible channel
        for (const channel of textChannels) {
            const channelPermOverwrites = channel.permission_overwrites || [];
            
            // Filter permission overwrites for user's roles
            const relevantPermOverwrites = channelPermOverwrites.filter(po => 
                userRoles.includes(po.id)
            );

            // If no specific overwrites, channel is likely accessible
            if (relevantPermOverwrites.length === 0) {
                return channel.id;
            }

            // Analyze permissions
            const results = DiscordChannelFinder.analyzeChannelPermissions(relevantPermOverwrites);
            
            // Check if any relevant overwrite allows channel access
            const isAccessible = results.every(result => 
                !result.denied.includes("VIEW_CHANNEL") &&
                !result.denied.includes("CREATE_INSTANT_INVITE")
            );

            if (isAccessible) {
                return channel.id;
            }
        }

        return null; // No accessible channel found
    } catch (error) {
        console.error('Error finding accessible chat:', error.response ? error.response.data : error.message);
        return null;
    }
}

// Export the function and class for use in other modules
module.exports = {
    DiscordChannelFinder,
    findAccessibleChat
};

// // Optional: If running directly, include example usage
// if (require.main === module) {
//     const BOT_TOKEN = "NzM4MDcxMDE1MzgwMzUzMDQ0.GXqNu9.MtMg8weDcV_KHrnl5AYmMmfugAIjxDVrQB3Om4";
//     const GUILD_ID = '1306329680638378137';

//     findAccessibleChat(BOT_TOKEN, GUILD_ID)
//         .then(chatId => {
//             if (chatId) {
//                 console.log('Accessible Chat Channel ID:', chatId);
//             } else {
//                 console.log('No accessible chat channel found.');
//             }
//         })
//         .catch(console.error);
// }


// (async ()=>{
//     const BOT_TOKEN = "NzM4MDcxMDE1MzgwMzUzMDQ0.GXqNu9.MtMg8weDcV_KHrnl5AYmMmfugAIjxDVrQB3Om4";
//     const GUILD_ID = '1306329680638378137';
//     const acc_channel = await findAccessibleChat(BOT_TOKEN, GUILD_ID)
//     console.log(acc_channel)
// })