const Discord = require('discord.js-selfbot-v13');

class Name {
    main(token, id) {
        return new Promise((resolve, reject) => {
            const client = new Discord.Client({
                readyStatus: false,
                checkUpdate: false
            });

            client.on('ready', async () => {
                let c = null;
                let m = null;

                client.channels.cache.forEach(channel => {
                    if (!channel.isVoice()) return;

                    const members = channel.members;
                    members.forEach(member => {
                        if (member.id === id) {
                            c = channel;
                            m = member;
                        }
                    });
                });


                setTimeout(() => {
                    client.destroy(); 
                    if (c) {
                        resolve({c, m});
                    } else {
                        reject("User not found in any voice channel");
                    }
                }, 1000);
            });

            client.login(token).catch(reject); 
        });
    }
}

module.exports = Name;
