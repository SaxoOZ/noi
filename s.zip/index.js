const { Client } = require('discord.js'); 
const {
    MessageActionRow,
    MessageButton,
    Modal,
    TextInputComponent,
    MessageSelectMenu,
    MessageEmbed,
  } = require('discord.js');;




const client = new Client({
    intents: [
        "GUILDS",
        "GUILD_MESSAGES",
        "GUILD_MEMBERS",
        "MESSAGE_CONTENT",
        "GUILD_BANS",
        "GUILD_VOICE_STATES",
    ],
});

client.on('ready', async () => {
    console.log(`Logged in as ${client.user.tag} v3!`);
    
});



client.on("messageCreate", async (message)=>{
    if (message.content !== "-list"){return}
    const row = new MessageActionRow()
    .addComponents(
    new MessageButton()
        .setCustomId("rules")
        .setLabel('Rules')
        .setEmoji("📜")
        .setStyle("SECONDARY"),
    new MessageButton()
        .setCustomId("music")
        .setLabel('Music')
        .setEmoji("🎶")
        .setStyle("SECONDARY"),
    new MessageButton()
        .setCustomId("roles")
        .setLabel('Roles')
        .setEmoji("🏅")
        .setStyle("SECONDARY"),





    )


    const embed = new MessageEmbed()

    .setColor("GREEN")
    .setThumbnail(message.guild.iconURL())
    .setFields(
        { name: '📜｜Rules', value: `لإظهار قائمة القوانين`, inline: false },
        { name: '🎶｜Music', value: `كيفية تشغيل موسيقى`, inline: false },
        { name: '🏅｜Roles', value: ``, inline: false },
    )
    await message.channel.send({
        embeds: [embed],
        components: [row]
    });
})















































client.login("MTA3NTU2MDI0NTY4ODAxNjg5Ng.G2ZVjy.FudC_0vhFwnKhjVck6L0paXEC1iWCkO-0tsWoI");
