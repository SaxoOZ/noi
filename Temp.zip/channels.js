export default [{
  name:"ﻲﺴﻠﺑﺍﺮﻄﻟﺍ ﺪﻤﺣﺃ ﺔﻋﺍﺫﺇ",
  ar:"إذاعة أحمد الطرابلسي",
  value:"https://Qurango.net/radio/ahmed_altrabulsi"
},{
  name:"ﻲﺴﻠﺑﺍﺮﻄﻟﺍ ﺮﻀﺧ ﺪﻤﺣﺃ ﺔﻋﺍﺫﺇ",
  ar:"إذاعة أحمد خضر الطرابلسي",
  value:"https://Qurango.net/radio/ahmad_khader_altarabulsi"
},{
  name:"ﻱﺮﺳﻭﺪﻟﺍ ﻢﻴﻫﺍﺮﺑﺍ ﺔﻋﺍﺫﺇ",
  ar:"إذاعة ابراهيم الدوسري",
  value:"https://Qurango.net/radio/ibrahim_aldosari"
},{
  name:"ﻲﻠﻘﻴﻌﻤﻟﺍ ﺮﻫﺎﻣ ﺔﻋﺍﺫﺇ",
  ar:"إذاعة ماهر المعيقلي",
  value:"https://Qurango.net/radio/maher_al_meaqli"
},{
  name:"ﺪﻤﺼﻟﺍﺪﺒﻋ ﻂﺳﺎﺒﻟﺍﺪﺒﻋ ﺔﻋﺍﺫﺇ",
  ar:"إذاعة عبدالباسط عبدالصمد",
  value:"https://Qurango.net/radio/abdulbasit_abdulsamad_warsh"
},{
  name:"ﻢﻳﺮﻜﻟﺍ ﻥﺍﺮﻘﻟﺍ ﺮﻴﺴﻔﺗ ﺔﻋﺍﺫﺇ",
  ar:"إذاعة تفسير القران الكريم",
  value:"https://qurango.net/radio/tafseer"
},{
  name:"ﺡﺎﺒﺼﻟﺍ ﺭﺎﻛﺫﺃ",
  ar:"أذكار الصباح",
  value:"https://qurango.net/radio/athkar_sabah"
},{
  name:"ﺀﺎﺴﻤﻟﺍ ﺭﺎﻛﺫﺃ",
  ar:"أذكار المساء",
  value:"https://qurango.net/radio/athkar_masa"
},{
  name:"ﻢﻳﺮﻜﻟﺍﺪﺒﻋ ﺪﻤﺤﻣ ﺔﻋﺍﺫﺇ",
  ar:"إذاعة محمد عبدالكريم",
  value:"https://Qurango.net/radio/mohammad_abdullkarem"
},{
  name:"ﺎﻨﺒﻟﺍ ﻲﻠﻋ ﺩﻮﻤﺤﻣ ﺔﻋﺍﺫﺇ",
  ar:"إذاعة محمود علي البنا",
  value:"https://Qurango.net/radio/mahmoud_ali__albanna"
},{
  name:"ﻱﺮﺼﺤﻟﺍ ﻞﻴﻠﺧ ﺩﻮﻤﺤﻣ ﺔﻋﺍﺫﺇ",
  ar:"إذاعة محمود خليل الحصري",
  value:"https://Qurango.net/radio/mahmoud_khalil_alhussary"
},{
  name:"ﻲﻔﻳﺬﺤﻟﺍ ﻲﻠﻋ ﺔﻋﺍﺫﺇ",
  ar:"إذاعة علي الحذيفي",
  value:"https://Qurango.net/radio/ali_alhuthaifi_qalon"
},{
  name:"ﺪﻤﺤﻣ ﺎﻨﻴﺒﻧ ﺓﺮﻴﺳ ﻦﻋ ﺔﻘﻠﺣ 004 - ﺔﻳﻮﺒﻨﻟﺍ ﺓﺮﻴﺴﻟﺍ",
  ar:"السيرة النبوية - 400 حلقة عن سيرة نبينا محمد",
  value:"https://Qurango.net/radio/fi_zilal_alsiyra"
},{
  name:"ﺲﻳﺪﺴﻟﺍ ﻦﻤﺣﺮﻟﺍﺪﺒﻋ ﺔﻋﺍﺫﺇ",
  ar:"إذاعة عبدالرحمن السديس",
  value:"https://Qurango.net/radio/abdulrahman_alsudaes"
},{
  name:"ﻲﻤﺠﻌﻟﺍ ﺪﻤﺣﺃ ﺔﻋﺍﺫﺇ",
  ar:"إذاعة أحمد العجمي",
  value:"https://Qurango.net/radio/ahmad_alajmy"
},{
  name:"ﺔﻳﺩﻮﻌﺴﻟﺍ ﺔﻟﻭﺩ ﻢﻳﺮﻜﻟﺍ ﻥﺍﺮﻘﻟﺍ ﺔﻋﺍﺫﺇ",
  ar:"إذاعة القران الكريم دولة السعودية",
  value:"http://n0e.radiojar.com/4wqre23fytzuv?rj-ttl=5&rj-tok=AAABgDTrkhEAsmBCfbT280gMag"
},{
  name:"ﺮﺼﻣ ﺔﻟﻭﺩ ﻢﻳﺮﻜﻟﺍ ﻥﺍﺮﻘﻟﺍ ﺔﻋﺍﺫﺇ",
  ar:"إذاعة القران الكريم دولة مصر",
  value:"http://n02.radiojar.com/v33ay8543d0uv?rj-ttl=5&rj-tok=AAABgDTqH90AIyBNaL5t4qE1IA"
},{
  name:"ﻦﻳﺮﺤﺒﻟﺍ ﺔﻟﻭﺩ ﻢﻳﺮﻜﻟﺍ ﻥﺍﺮﻘﻟﺍ ﺔﻋﺍﺫﺇ",
  ar:"إذاعة القران الكريم دولة البحرين",
  value:"https://prod-34-82-94-205.wostreaming.net/ihorizonsradio-sakfmmp3-ibc1?session-id=3453c3202479222be48941d99f762a88"
},{
  name:"ﻱﺪﻣﺎﻐﻟﺍ ﺪﻌﺳ ﺔﻋﺍﺫﺇ",
  ar:"إذاعة سعد الغامدي",
  value:"https://Qurango.net/radio/saad_alghamdi"
}]