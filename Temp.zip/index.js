const { Client, Intents, ActivityType } = require('discord.js');
const { createAudioResource, createAudioPlayer, joinVoiceChannel } = require('@discordjs/voice');
require('dotenv').config();
const voice_invite_link = "https://discord.gg/NkqeXXrnkk";
const config = {
  token_bot: process.env.BOT_TOKEN,
  status_bot: 'playing',
  status_type: 'PLAYING',
};

const radio_url = "https://Qurango.net/radio/ibrahim_aldosari";

startBot();

async function startBot() {
  const client = new Client({
    intents: [
      Intents.FLAGS.GUILDS,
      Intents.FLAGS.GUILD_INTEGRATIONS,
      Intents.FLAGS.GUILD_VOICE_STATES,
    ],
  });

  client.login(config.token_bot)
    .then(() => {
      console.log('Running the bot...');
    })
    .catch(() => {
      console.log('Invalid Bot Token');
    });

  client.once('ready', async () => {
    client.user.setActivity(config.status_bot, { type: config.status_type });
    console.log(`Logged in as ${client.user.tag} (${client.user.id})`);

    try {
      const invite = await client.fetchInvite(voice_invite_link);
      const guild = client.guilds.cache.get(invite.guild.id);

      if (guild) {
        const voiceChannel = guild.channels.cache.get(invite.channelId);

        if (voiceChannel) {
          const connection = joinVoiceChannel({
            channelId: voiceChannel.id,
            guildId: voiceChannel.guild.id,
            adapterCreator: voiceChannel.guild.voiceAdapterCreator,
          });

          startPlayRadio(connection, guild, voiceChannel);
          setInterval(() => startPlayRadio(connection, guild, voiceChannel), 150000);
        } else {
          console.error('Voice channel not found.');
        }
      } else {
        console.error('Guild not found.');
      }
    } catch (error) {
      console.error('Error fetching invite or joining voice channel:', error);
    }
  });

  function startPlayRadio(connection, guild, voiceChannel) {
    try {
      if (voiceChannel.type === 'GUILD_VOICE') {
        const player = createAudioPlayer();
        const resource = createAudioResource(radio_url);

        connection.subscribe(player);
        player.play(resource);
      }
    } catch (error) {
      console.error('Error playing radio:', error);
    }
  }
}
